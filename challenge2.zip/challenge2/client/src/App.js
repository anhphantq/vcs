import Main from "./pages/main";
import { Routes, Route, Link } from "react-router-dom";

function App() {
  return <Main></Main>;
}

export default App;
